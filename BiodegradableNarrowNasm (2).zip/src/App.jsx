 React from 'react';
 header from' react';
function Footer() {
  return (
    <Footer>
    <p>copyright@2021</p>
    </Footer>
  );
}

export default Footer;