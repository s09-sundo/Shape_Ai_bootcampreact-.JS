import React from 'react';
 import header from' react';
 import Footer from'react';
function Footer() {
  return (
    <Footer>
    <p>copyright@2021</p>
    </Footer>
  );
}

export default Footer;